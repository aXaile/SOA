package fr.insa.sensor;

import java.io.IOException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("presence")
public class PresenceSensorRessource {
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public boolean getPresence() throws IOException{
		return PresenceSensor.getPresenceInTheRoom();
	}

}
