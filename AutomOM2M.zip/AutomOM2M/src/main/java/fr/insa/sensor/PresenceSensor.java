package fr.insa.sensor;

import java.io.IOException;

import org.eclipse.om2m.commons.resource.ContentInstance;

import fr.insat.om2m.tp2.mapper.Mapper;
import fr.insat.om2m.tp2.mapper.MapperInterface;
import httpRequest.HttpRequest;

public class PresenceSensor {

	private static MapperInterface mapper =new Mapper();
	public static boolean getPresenceInTheRoom() throws IOException{
		HttpRequest req=new HttpRequest();
		String data=req.getReq("http://127.0.0.1:8080/~/in-cse/in-name/Presence_sensor/DATA/la");
		ContentInstance cin=(ContentInstance)mapper.unmarshal(data);
		System.out.println("essai1 : "+cin.getContent());
		if (cin.getContent().contains("true")){
			return true;
		}else;
		return false;
		
	}

}
