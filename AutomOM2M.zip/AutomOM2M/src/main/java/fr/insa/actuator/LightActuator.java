package fr.insa.actuator;


public class LightActuator {
	private static boolean etatDeLaLumiere = true;
		
	public String getEtatDeLaLumiere(){
		if(etatDeLaLumiere){
			System.out.println("La lumiere est allumee");
			return "On";
		}else{
			System.out.println("La lumiere est eteinte");
			return "Off";
		}
	}
	
	public void setEtatDeLaLumiere(boolean etat){
		LightActuator.etatDeLaLumiere = etat;
		System.out.println("Mise � jour jour de la lumi�re r�ussi : son �tat est maintenant "+this.getEtatDeLaLumiere());
	}
}
